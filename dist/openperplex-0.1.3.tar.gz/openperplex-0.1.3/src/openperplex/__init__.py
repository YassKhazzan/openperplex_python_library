# Contents of src/openperplex/__init__.py
from .openperplex import Openperplex, OpenperplexError
